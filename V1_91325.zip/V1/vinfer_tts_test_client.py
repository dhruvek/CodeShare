
import requests
import base64

SERVER = "http://35.200.228.189:8009"

# Create profile
def create_profile():
    with open("sample.wav", "rb") as f:
        audio_b64 = base64.b64encode(f.read()).decode("utf-8")
    payload = {
        "speaker_id": "test_speaker",
        "reference_audio": audio_b64,
        "reference_text": "Hello, this is a reference.",
        "user_id": "tester"
    }
    r = requests.post(f"{SERVER}/create_profile", json=payload)
    print("Create Profile:", r.json())

# Synthesize
def synthesize():
    payload = {
        "text": "Testing synthesis via HTTP.",
        "speaker_id": "test_speaker",
        "language_id": "en",
        "exaggeration": 0.5,
        "user_id": "tester"
    }
    r = requests.post(f"{SERVER}/synthesize", json=payload)
    with open("output.wav", "wb") as f:
        f.write(r.content)
    print("Saved output.wav")

create_profile()
synthesize()
